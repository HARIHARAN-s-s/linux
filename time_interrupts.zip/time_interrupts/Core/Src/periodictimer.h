/*
 * periodictimer.h
 *
 *  Created on: May 29, 2024
 *      Author: boobathi
 */

#ifndef SRC_PERIODICTIMER_H_
#define SRC_PERIODICTIMER_H_

void periodictimer(void);

#endif /* SRC_PERIODICTIMER_H_ */
