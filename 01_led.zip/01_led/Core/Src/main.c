#include "led_blink.h"
int main()
{
	led_blink();
	return 0;
}
