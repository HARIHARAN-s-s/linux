/*
 * led_blink.h
 *
 *  Created on: May 29, 2024
 *      Author: boobathi
 */

#ifndef SRC_LED_BLINK_H_
#define SRC_LED_BLINK_H_

void led_blink();

#endif /* SRC_LED_BLINK_H_ */
