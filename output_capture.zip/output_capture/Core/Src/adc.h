/*
 * adc.h
 *
 *  Created on: 09-May-2024
 *      Author: srees
 */


