/*
 * systick.h
 *
 *  Created on: May 29, 2024
 *      Author: boobathi
 */

#ifndef SRC_SYSTICK_H_
#define SRC_SYSTICK_H_

void systick(void);

#endif /* SRC_SYSTICK_H_ */
