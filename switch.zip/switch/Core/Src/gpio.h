/*
 * gpio.h
 *
 *  Created on: May 29, 2024
 *      Author: boobathi
 */

#ifndef SRC_GPIO_H_
#define SRC_GPIO_H_

#include "stm32f4xx.h"
void GPIO_Init(void);

#endif /* SRC_GPIO_H_ */
